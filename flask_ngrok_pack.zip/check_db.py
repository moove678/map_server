from sqlalchemy import create_engine

try:
    engine = create_engine("postgresql://postgres:postgres@localhost:5432/mydb")
    conn = engine.connect()
    conn.close()
    print("БД работает")
except Exception as e:
    print("Ошибка подключения к базе:", e)
    exit(1)
