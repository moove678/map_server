#!/bin/bash

echo "===========[1/5] Запуск PostgreSQL =========="
sudo service postgresql start

echo "===========[2/5] Проверка соединения с базой =========="
python3 check_db.py
if [ $? -ne 0 ]; then
    echo "Ошибка подключения к БД. Останавливаемся."
    exit 1
fi

echo "===========[3/5] Применение миграций =========="
flask db upgrade

echo "===========[4/5] Запуск сервера и Ngrok =========="
python3 main.py
